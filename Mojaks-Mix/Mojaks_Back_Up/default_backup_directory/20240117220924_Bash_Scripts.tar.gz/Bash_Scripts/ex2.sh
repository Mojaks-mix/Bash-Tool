#! bin/bash
hello_text="Hello World"
echo $hello_text + 1
