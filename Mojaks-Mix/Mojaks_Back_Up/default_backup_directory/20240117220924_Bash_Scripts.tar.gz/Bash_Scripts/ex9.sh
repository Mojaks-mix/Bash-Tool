#!/bin/bash
# This loop runs 10 times.
for ((counter=1; counter<=10; counter++))
do
   echo "Hello! This is loop number ${counter}."
   sleep 1
done
# After the for-loop finishes, print a goodbye message.
echo "All done"

