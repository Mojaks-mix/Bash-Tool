#! bin/bash
STRING="MOHAMMAD"
echo "This is a variable in bash: $STRING"
