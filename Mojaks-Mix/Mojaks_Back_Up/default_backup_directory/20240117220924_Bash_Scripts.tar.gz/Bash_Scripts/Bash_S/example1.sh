#! bin/bash

echo "My name is $1 and I live in $2"
