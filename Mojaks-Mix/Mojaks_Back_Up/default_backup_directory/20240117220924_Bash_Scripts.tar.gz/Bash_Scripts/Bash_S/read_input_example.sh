#! bin/bash

echo "What is your name?"

read name

echo "welcome $name"
