source ./second.sh
func1 love horror
func2 134 999
