#! bin/bash
echo "Hello"
function func1()
{
echo "I love $1 and $2"
}
function func2()
{
result=$(($1+$2))
echo $result
}
