#!/bin/bash
# Infinite while loop.
while true
    do
		echo "Hello!"
		sleep 1 # Wait for 1 second.
    done

