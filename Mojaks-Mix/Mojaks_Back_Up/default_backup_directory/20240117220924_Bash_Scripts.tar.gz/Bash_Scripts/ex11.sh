#!/bin/bash
# Define the function before we call it.
hello_world() {
echo "Hello world!"
}
# Call the function we defined earlier:
hello_world

