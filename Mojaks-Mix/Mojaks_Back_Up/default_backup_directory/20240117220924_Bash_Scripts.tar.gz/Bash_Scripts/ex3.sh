#! bin/bash
echo "Welcome $1"
